using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WolfScript : MonoBehaviour
{
    public GameObject hunter;
    public float slowRadius = 3.0f;
    public float maxSpeed = 7.0f;
    public float maxAcceleration = 5.0f;
    public float maxAngularVelocity = 30f;
    public float maxAngularAcceleration = 30f;

    // Properties for wander algorithm
    private GameObject wanderCircle;
    private GameObject wanderPoint;
    private const float wanderRadius = 1.5f;
    private const float wanderDistance = 3;
    private float wanderTimer;

    private float detectRadius = 3;
    private bool detected = false;

    public float spawnTimer = 0;
    public float sceneTimer1 = 30;

    private GameObject wanderText;
    private GameObject evadeText;

    // Start is called before the first frame update
    void Start()
    {
        // Randomize spawn location
        transform.position = new Vector3
        (
            Random.Range(-14, 14),  // x-ccordinate
            Random.Range(-6, 6),   // y-coordinate
            0
        );

        wanderText = GameObject.Find("WolfWander");
        evadeText = GameObject.Find("WolfEvade");

        wanderText.SetActive(false);
        evadeText.SetActive(false);

        wanderCircle = transform.Find("Wander Circle").gameObject;
        wanderCircle.transform.localScale = new Vector3(wanderRadius * 2, wanderRadius * 2, 1);
        wanderCircle.transform.localPosition = new Vector3(0, wanderDistance, 0);
        
        wanderPoint = transform.Find("Wander Point").gameObject;
        wanderPoint.transform.localScale = new Vector3(0.1f, 0.1f, 1);

        Hide();

        // Testing angular velocity for align (Does not work on my end)
        /*
        GetComponent<Rigidbody2D>().angularVelocity = 100f;
        Debug.Assert(GetComponent<Rigidbody2D>().angularVelocity != 0);
        */
    }

    // Update is called once per frame
    void Update()
    {
        if (spawnTimer > 0)
        {
            spawnTimer = Mathf.Max(spawnTimer - Time.deltaTime, 0);
            Debug.Log(spawnTimer);
            return;
        }


        GetComponent<SpriteRenderer>().enabled = true;
        
        // GetComponent<Rigidbody2D>().rotation = NormalizeAngle(GetComponent<Rigidbody2D>().rotation);

        var targetPosition = hunter.transform.position + (Vector3)hunter.GetComponent<Rigidbody2D>().velocity * Time.deltaTime;

        var dir = transform.position - targetPosition;
        var dist = (hunter.transform.position - transform.position).magnitude;
        if (!detected && dist > detectRadius)
        {
            wanderText.SetActive(true);
            wanderCircle.GetComponent<SpriteRenderer>().enabled = true;
            wanderPoint.GetComponent<SpriteRenderer>().enabled = true;
            Wander();
            detectRadius += 2 * Time.deltaTime;
        }
        /*
        else if (dist < slowRadius)
        {
            slowCircle.SetActive(true);
            Arrive(dir);
        }
        */
        else
        {
            detected = true;
            wanderCircle.GetComponent<SpriteRenderer>().enabled = false;
            wanderPoint.GetComponent<SpriteRenderer>().enabled = false;
            Flee(dir);
        }
    }

    private void Seek(Vector3 dir)
    {
        /*
        var targetPosition = player.transform.position + (Vector3)playerBody.velocity * Time.deltaTime;
        var dir = targetPosition - transform.position;
        */

        float acceleration = Mathf.Min(dir.magnitude, maxAcceleration);
        float speed = GetComponent<Rigidbody2D>().velocity.magnitude;
        var velocity = dir.normalized * Mathf.Min(speed + acceleration * Time.deltaTime, maxSpeed);

        GetComponent<Rigidbody2D>().velocity = velocity;


        // Align character with the direction it is heading
        var angle = Mathf.Rad2Deg * Mathf.Acos(Vector3.Dot(velocity, new Vector3(0, 1, 0)) / velocity.magnitude);
        angle *= Mathf.Sign(-GetComponent<Rigidbody2D>().velocity.x);

        // Simple Align
        GetComponent<Rigidbody2D>().rotation = angle;

        // Kinesthetic Align (Implemented but does not work due to external bug)
        //Align(angle);
    }

    private void Flee(Vector3 dir)
    {
        wanderText.SetActive(false);
        evadeText.SetActive(true);

        float acceleration = Mathf.Min(dir.magnitude, maxAcceleration);
        float speed = GetComponent<Rigidbody2D>().velocity.magnitude;
        var velocity = dir.normalized * Mathf.Min(speed + acceleration * Time.deltaTime, maxSpeed);

        GetComponent<Rigidbody2D>().velocity = velocity;

        // Align character with the direction it is heading
        var angle = Mathf.Rad2Deg * Mathf.Acos(Vector3.Dot(velocity, new Vector3(0, 1, 0)) / velocity.magnitude);
        angle *= Mathf.Sign(hunter.transform.position.x - transform.position.x);

        // Simple Align
        GetComponent<Rigidbody2D>().rotation = angle;

        // Kinesthetic Align (Implemented but does not work due to external bug)
        //Align(angle);
    }

    private void Align(float angle)
    {
        /*
        float acceleration = Mathf.Clamp(angle, -maxAngularAcceleration, maxAngularAcceleration);
        float speed = GetComponent<Rigidbody2D>().angularVelocity;
        var velocity = Mathf.Clamp(speed + acceleration * Time.deltaTime, -maxAngularVelocity, maxAngularVelocity);
        */
        if (Mathf.Abs(angle) < 45)
        {
            float acceleration = Mathf.Clamp(angle, -maxAngularAcceleration, maxAngularAcceleration);
            GetComponent<Rigidbody2D>().angularVelocity -= Mathf.Sign(angle) * acceleration * Time.deltaTime;
        }
        else
        {
            GetComponent<Rigidbody2D>().angularVelocity = -Mathf.Sign(angle) * maxAngularVelocity;
        }
    }

    //return angle in range -360 to 360
    private float NormalizeAngle(float a)
    {
        return a - 360f * Mathf.Floor((a + 360f) / 360f);
    }

    private void Wander()
    {
        wanderText.SetActive(true);
        evadeText.SetActive(false);

        if (wanderTimer < 0.1f)
        {
            wanderTimer += Time.deltaTime;
            return;
        }
        wanderCircle.SetActive(true);
        wanderPoint.SetActive(true);
        var targetDegree = UnityEngine.Random.Range(0, 360);
        var targetPos = new Vector3(Mathf.Cos(targetDegree), Mathf.Sin(targetDegree), 0);
        targetPos *= wanderRadius;
        targetPos += wanderCircle.transform.position;

        wanderPoint.transform.position = targetPos;

        /*
        Debug.Log(targetPos);
        Debug.Log(wanderPoint.transform.position);
        */

        var dir = targetPos - transform.position;
        Seek(dir);
        wanderTimer = 0f;
    }

    private void Hide()
    {
        GetComponent<SpriteRenderer>().enabled = false;
        wanderCircle.GetComponent<SpriteRenderer>().enabled = false;
        wanderPoint.GetComponent<SpriteRenderer>().enabled = false;
    }
}
