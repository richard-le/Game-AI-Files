using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HunterScript : MonoBehaviour
{
    public GameObject wolf;
    public float slowRadius = 3.0f;
    public float maxSpeed = 3.0f;
    public float maxAcceleration = 3.0f;
    public float maxAngularVelocity = 30f;
    public float maxAngularAcceleration = 30f;

    private GameObject slowCircle;
    private GameObject targetCircle;

    private GameObject wanderCircle;
    private GameObject wanderPoint;
    private const float wanderRadius = 1.5f;
    private const float wanderDistance = 3;
    private float wanderTimer;

    private float detectRadius = 3;
    private bool detected = false;

    private float spawnTimer;
    // private float sceneTimer1;

    private GameObject wanderText;
    private GameObject pursueText;

    // Start is called before the first frame update
    void Start()
    {
        // Randomize spawn location
        transform.position = new Vector3
        (
            UnityEngine.Random.Range(-14, 14),  // x-ccordinate
            UnityEngine.Random.Range(-6, 6),   // y-coordinate
            0
        );

        wanderText = GameObject.Find("HunterWander");
        pursueText = GameObject.Find("HunterPursue");

        wanderText.SetActive(false);
        pursueText.SetActive(false);

        spawnTimer = wolf.GetComponent<WolfScript>().spawnTimer;
        // sceneTimer1 = wolf.GetComponent<WolfScript>().sceneTimer1;

        slowCircle = transform.Find("Slow Zone").gameObject;
        slowCircle.transform.localScale = new Vector3(slowRadius * 2, slowRadius * 2, 1);

        targetCircle = transform.Find("Predicted Position").gameObject;
        targetCircle.transform.localScale = new Vector3(.25f, .25f, 1);

        wanderCircle = transform.Find("Wander Circle").gameObject;
        wanderCircle.transform.localScale = new Vector3(wanderRadius * 2, wanderRadius * 2, 1);
        wanderCircle.transform.localPosition = new Vector3(0, wanderDistance, 0);

        wanderPoint = transform.Find("Wander Point").gameObject;
        wanderPoint.transform.localScale = new Vector3(0.1f, 0.1f, 1);
        wanderPoint.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        if (spawnTimer > 0)
        {
            spawnTimer = Mathf.Max(spawnTimer - Time.deltaTime, 0);
            Wander();
            return;
        }

        // GetComponent<Rigidbody2D>().rotation = NormalizeAngle(GetComponent<Rigidbody2D>().rotation);

        var targetPosition = wolf.transform.position + (Vector3)wolf.GetComponent<Rigidbody2D>().velocity * Time.deltaTime;
        targetCircle.transform.position = targetPosition;

        var dir = targetPosition - transform.position;
        var dist = (wolf.transform.position - transform.position).magnitude;
        if (!detected || dist > detectRadius)
        {
            detected = true;
            wanderCircle.GetComponent<SpriteRenderer>().enabled = true;
            wanderPoint.GetComponent<SpriteRenderer>().enabled = true;
            Wander();
            detectRadius += 2 * Time.deltaTime;
        }
        else if (dist < slowRadius)
        {
            wanderCircle.GetComponent<SpriteRenderer>().enabled = false;
            wanderPoint.GetComponent<SpriteRenderer>().enabled = false;
            slowCircle.SetActive(true);
            Arrive(dir);
        }
        else
        {
            wanderText.SetActive(false);
            pursueText.SetActive(true);
            wanderCircle.GetComponent<SpriteRenderer>().enabled = false;
            wanderPoint.GetComponent<SpriteRenderer>().enabled = false;
            slowCircle.SetActive(false);
            Seek(dir);
        }
    }
    
    // Seek Wolf using predicted location
    private void Seek(Vector3 dir)
    {

        /*
        var targetPosition = player.transform.position + (Vector3)playerBody.velocity * Time.deltaTime;
        var dir = targetPosition - transform.position;
        */

        float acceleration = Mathf.Min(dir.magnitude, maxAcceleration);
        float speed = GetComponent<Rigidbody2D>().velocity.magnitude;
        var velocity = dir.normalized * Mathf.Min(speed + acceleration * Time.deltaTime, maxSpeed);

        GetComponent<Rigidbody2D>().velocity = velocity;

        
        // Align character with the direction it is heading
        var angle = Mathf.Rad2Deg * Mathf.Acos(Vector3.Dot(velocity, new Vector3(0, 1, 0)) / velocity.magnitude);
        angle *= Mathf.Sign(-GetComponent<Rigidbody2D>().velocity.x);

        // Simple Align
        GetComponent<Rigidbody2D>().rotation = angle;

        // Kinesthetic Align (Implemented but does not work due to external bug)
        //Align(angle);
    }

    private void Arrive(Vector3 dir)
    {
        var targetSpeed = maxSpeed * dir.magnitude / slowRadius;
        var targetVelocity = dir.normalized * targetSpeed;
        var steeringLinear = targetVelocity - (Vector3)GetComponent<Rigidbody2D>().velocity;

        var timeToTarget = 0.1f;
        steeringLinear = steeringLinear / timeToTarget;

        Seek(steeringLinear);
    }

    private void Align(float angle)
    {
        /*
        float acceleration = Mathf.Clamp(angle, -maxAngularAcceleration, maxAngularAcceleration);
        float speed = GetComponent<Rigidbody2D>().angularVelocity;
        var velocity = Mathf.Clamp(speed + acceleration * Time.deltaTime, -maxAngularVelocity, maxAngularVelocity);
        */
        if (Mathf.Abs(angle) < 45)
        {
            float acceleration = Mathf.Clamp(angle, -maxAngularAcceleration, maxAngularAcceleration);
            GetComponent<Rigidbody2D>().angularVelocity -= Mathf.Sign(angle) * acceleration * Time.deltaTime;
        }
        else
        {
            GetComponent<Rigidbody2D>().angularVelocity = -Mathf.Sign(angle) * maxAngularVelocity;
        }
    }

    //return angle in range -180 to 180
    private float NormalizeAngle(float a)
    {
        return a - 360f * Mathf.Floor((a + 360f) / 360f);
    }

    private void Wander()
    {
        wanderText.SetActive(true);
        pursueText.SetActive(false);

        if (wanderTimer < 0.1f)
        {
            wanderTimer += Time.deltaTime;
            return;
        }
        var targetDegree = UnityEngine.Random.Range(0, 360);
        var targetPos = new Vector3(Mathf.Cos(targetDegree), Mathf.Sin(targetDegree), 0);
        targetPos *= wanderRadius;
        targetPos += wanderCircle.transform.position;

        wanderPoint.transform.position = targetPos;

        /*
        Debug.Log(targetPos);
        Debug.Log(wanderPoint.transform.position);
        */

        var dir = targetPos - transform.position;
        Seek(dir);
        wanderTimer = 0f;
    }
}
